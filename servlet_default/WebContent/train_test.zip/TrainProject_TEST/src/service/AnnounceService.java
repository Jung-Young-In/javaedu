package service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import util.ScanUtil;
import util.View;
import dao.AnnounceDao;

public class AnnounceService {
	// 싱글톤 패턴
	private AnnounceService() {}

	private static AnnounceService instance;

	public static AnnounceService getInstance() {
		if (instance == null) {
			instance = new AnnounceService();
		}
		return instance;
	}
	//private AnnounceDao dao;
	private AnnounceDao announceDao = AnnounceDao.getInstance();
	
	//공지사항 목록 출력 메서드
	public int announce(){
		List<Map<String, Object>> annList = announceDao.selectAnnounceList();
		
		System.out.println("====================================================");
		System.out.println("번호\t이름\t제목\t내용\t작성일");
		System.out.println("====================================================");
		for(Map<String, Object> announce : annList){
			System.out.println(announce.get("ANN_ID")
					+ "\t" + announce.get("ADMIN_NM")
					+ "\t" + announce.get("ANN_SUBJECT")
					+ "\t" + announce.get("ANN_CONTENT")
					+ "\t" + announce.get("ANN_DATE"));
		}
		System.out.println("====================================================");

		return View.ANNOUNCE_LIST; 
	};
	
	// DAO에 INSERT 메서드 작성 끝났으니까 이제 서비스에서 
	public int insertAnnounce(List<Object> param) {
		int result = 0;
		// 인서트 성공시 1, 실패시 0 이 반환된다.
		if(announceDao.insertAnnounce(param) == 1) {
			// 인서트 성공시 result는 1이 되어야함.
			result = 1;
		}else {
			// 인서트 실패시 result는 0
			result = 0;
			
		}
		return result;
	}
	
	public int deleteAnnounce(List<Object> param) {
		int result = 0;
		// 인서트 성공시 1, 실패시 0 이 반환된다.
		if(announceDao.deleteAnnounce(param) == 1) {
			// 인서트 성공시 result는 1이 되어야함.
			result = 1;
		}else {
			// 인서트 실패시 result는 0
			result = 0;
			
		}
		return result;
	}
	
	public int updateAnnounce(List<Object> param) {
		int result = 0;
		// 인서트 성공시 1, 실패시 0 이 반환된다.
		if(announceDao.updateAnnounce(param) == 1) {
			// 인서트 성공시 result는 1이 되어야함.
			result = 1;
		}else {
			// 인서트 실패시 result는 0
			result = 0;
			
		}
		return result;
	}


	// insert service메서드는 이렇게 끝이에요 넵 음. 완벽히 이해는 못했지만 어느정도 이해를 했고 써주신거를 뜯어보면서 한번 더 이해를 해봐야할거 같아요 
	// 그럼 서비스를 컨트롤러에서 써야돼요
}
