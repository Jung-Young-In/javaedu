package service;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import controller.Controller;
import dao.AuthenException;
import dao.UserDao;
import dao.membershipDao;
import dao.trainDTO;
import dao.trainException;
import util.ScanUtil;
import util.View;

public class UserService {

	Scanner sc = new Scanner(System.in);
	membershipDao dao = new membershipDao();
	
	trainException ne = new trainException();
	
	//회원가입
	
	public void insert() throws AuthenException{
		
		String pw2 = null;
		boolean id = true;
		boolean pw = true;
			boolean name = true;
		boolean birth = true;
		boolean tel = true;
		boolean add = true;
		boolean account = true;
		
		System.out.println("회원가입>");
		System.out.println("--------------------");
		
		try {
			trainDTO dto = new trainDTO();
			
			do {
				try {
					System.out.println("아이디");
					dto.setId(sc.next());
					ne.idFormat(dto.getId());
					
					id = false;
					
				} catch (AuthenException e) {
					System.out.println(e.toString());
				}
			} while(id);
			
			
			do {
				try {
					System.out.println("비밀번호");
					dto.setPw(sc.next());
					
					System.out.println("비밀번호 확인");
					pw2 = sc.next();
					ne.pwCheck(dto.getPw(), pw2);
					
					pw = false;
			
		} catch (AuthenException e) {
			System.out.println(e.toString());
		
		}

		}while(name);
			
		
			do {
				try {
					System.out.println("");
				}
			}
				
			}
	}
	
	

}