package service;

public class AdminService {
	private AdminService() {}

	private static AdminService instance;

	public static AdminService getInstance() {
		if (instance == null) {
			instance = new AdminService();
		}
		return instance;
	}
	
	private AdminService AdminDao = AdminService.getInstance();
}
