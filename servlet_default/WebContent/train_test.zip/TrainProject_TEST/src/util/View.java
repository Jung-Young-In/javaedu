package util;

public class View { //화면정의
	
	public static final int HOME = 0; //사용자 관점 초기 화면
	public static final int ANNOUNCE_LIST = 1; //공지사항 화면
	public static final int LOGIN = 2; //로그인
	public static final int JOIN = 3; //로그인
	public static final int MAINHOME = 4; //사용자관점 메인화면
	public static final int ADMINHOME = 5; //사용자관점 메인화면
	

}
