package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import service.AnnounceService;
import service.UserService;
import util.ScanUtil;
import util.View;

//Controller 화면이동 / 메뉴
public class Controller {

	public static void main(String[] args) {

		new Controller().start();
	}
	//사용자가 로그인을 했으면, 로그인 접속 정보를 가지고 있어야 하기 때문에 생성.
	public static Map<String, Object> LoginUser;
	
	private UserService userService = UserService.getInstance();
	private AnnounceService announceService= AnnounceService.getInstance();
	
	private void start() {
		int view = View.HOME;

		while (true) {
			switch (view) {
			case View.HOME: view = home(); break;
			//case View.ANNOUNCE_LIST: view = announceService.annList(); break;
			case View.LOGIN: view = userService.login(); break;
			case View.JOIN: view = userService.join(); break;
			case View.MAINHOME: view = mainmenu(); break;
			case View.ADMINHOME: view = adminhome(); break;
			}
		}

	}


	private int adminhome() {
		System.out.println("-------------------------------------------");
		System.out.println("1.로그인\t2.역 관리\t3.기차 관리\t4.사용자관리");
		System.out.println("-------------------------------------------");
		System.out.println("번호 입력>");
		
		int input = ScanUtil.nextInt();
		switch(input){
		case 1: break;
		case 2: break;
		case 3: break;
		case 4: break;
		}
		return View.ADMINHOME;
	}


	private int mainmenu() {
		System.out.println("-------------------------------------------");
		System.out.println("1.승차권 예매\t2.기차 일정표\t3.마이페이지\t4.고객센터");
		System.out.println("-------------------------------------------");
		System.out.println("번호 입력>");
		
		int input = ScanUtil.nextInt();
		switch(input){
		case 1: userService.booking(); break;
		case 2: break;
		case 3: break;
		case 4: break;
		}
		return View.HOME;
	}


	private int home() {
		System.out.println("---------------------------------");
		System.out.println("1.로그인\t2.공지사항\t0.프로그램 종료");
		System.out.println("---------------------------------");
		System.out.println("번호 입력>");
		
		int input = ScanUtil.nextInt();
		switch(input){
		case 1: return View.LOGIN; 
		case 2: return View.ANNOUNCE_LIST; // 공지사항 화면으로 이동.. 
		case 0:
			System.out.println("프로그램이 종료되었습니다.");
			System.exit(0);
		}
		return View.HOME;
	}
	
	private void announceInsert() {
		//ann_id, ann_nm, ann_subject, ann_content, ann_date, ad_id  이 순서랑
		System.out.println("---------------------------------");
		System.out.println("제목 입력>");
		String inputSub = ScanUtil.nextLine();
		
		System.out.println("내용입력>");
		String inputCon = ScanUtil.nextLine();
		//주석에 순서대로 넣어야해요 annId가 게시글 번호 번호는 그럼 1씩 증가하겠네요
		//select 'an'||count(ann_id)+1 from announce; 이런 쿼리로 조회하면 ad01, ad02, ad03 이런식으로 증가돼요 게시글 갯수에 따라서
		// 그렇게 하려면 게시글 작성 전에 select 한번 더 날려서 저 반환값 받아와서 ex. ad03 그걸 지금 여기서 작성할때 넣어줘야해여 
		List<Object> ann = new ArrayList<Object>();
		// 그 게시글 번호가 겹치지않게 생성되려면 그렇게 하는게 맞아요 근데 쿼리가 좀 다를뿐 1씩 증하게 하려고 해도
		// select count(ann_id)+1 from announce;    ('an'|| 앞에 붙은 이것만 안쓰는거라 똑같다고 보면돼요)
		// 그럼 게시글번호 조회해서 넣어주는건 끝났다 치고
		ann.add("ann_id");
		ann.add("ann_nm"); // 여기다 영인브로가 조회해서 넣어주면 돼요
		ann.add(inputSub); // 제목 입력받고
		ann.add(inputCon);
		ann.add("ann_date");
		ann.add("ad_id");
		// ann.add(); content 입력받고
		// anndate는 쿼리로 넣어줘도되고 java에서 오늘날짜나 시간 가져와서 넣어줘도되고
		// ad_id는 현재 로그인한 관리자 아이디 넣어주면 되요
		
		announceService.insertAnnounce(ann);
		if(announceService.insertAnnounce(ann) == 1) {
			System.out.println("공지사항 작성이 완료되었습니다.");
		}else {
			System.out.println("공지사항 작성이 실패하였습니다.");
		}
		}
		// 이런식으로 하면 될것같아요 List 에서 add는 줄 순서에 따라서 들어가니까 add 순서랑 맞춰서 scanner 로 입력받고
		// 근데 제목 입력받고 nter나 뭐 콘솔에서 치겠죠? content 입력받고 또 엔터쳐서 넘기면 작성일자랑 adId는 입력 안받아도 되니까 
		// 입력 받을건 제목,내용? 정도네요
		// 하나 입력받고 다음으로 넘기고 또 입력받고 작성 종료하는건 한번 해봐요 ㅎㅎ 
		// update는 똑같이 하시면 되고, delete는 리턴 1 or 0만 받고 syso만 띄워주면 될걳같아요


	private void announceDelete() {
		System.out.println("---------------------------------");
		System.out.println("공지 코드 입력>");
		String inputAnnId = ScanUtil.nextLine();
		
		System.out.println("공지 번호 입력>");
		String inputAnnNm = ScanUtil.nextLine();

		List<Object> annDelete = new ArrayList<Object>();

		annDelete.add(inputAnnId);
		annDelete.add(inputAnnNm); 
		
		
		announceService.updateAnnounce(annDelete);
		if(announceService.updateAnnounce(annDelete) == 1) {
			System.out.println("공지사항 삭제가 완료되었습니다.");
		}else {
			System.out.println("공지사항 삭제가 실패하였습니다.");
		}
	}
	
	
	private void announceUpdate() {
		
		System.out.println("---------------------------------");
		System.out.println("제목 입력>");
		String inputSub = ScanUtil.nextLine();
		
		System.out.println("내용입력>");
		String inputCon = ScanUtil.nextLine();

		List<Object> annUpdate = new ArrayList<Object>();
		
		annUpdate.add("ann_id");
		annUpdate.add("ann_nm"); 
		annUpdate.add(inputSub); 
		annUpdate.add(inputCon);
		annUpdate.add("ann_date");
		annUpdate.add("ad_id");
	

		announceService.updateAnnounce(annUpdate);
		if(announceService.updateAnnounce(annUpdate) == 1) {
			System.out.println("공지사항 업데이트가 완료되었습니다.");
		}else {
			System.out.println("공지사항 업데이트가 실패하였습니다.");
		}
		
	}
}
//Controller 클래스
