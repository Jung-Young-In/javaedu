package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class membershipDao {

	
	
	//1. insert
	
	public int insertData(trainDTO dto) {
		int result = 0;
		
		Connection conn = DBconn.getConnection();
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			sql = "insert into customer (id, pw, name, birth, tel, add, account)";
			sql +="values(?,?,?,?,?,?,?)";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getBirth());
			pstmt.setString(5, dto.getTel());
			pstmt.setString(6, dto.getAdd());
			pstmt.setString(7, dto.getAccount());
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return result;
	}
	
	
	//2. update
	
	public int updateData(trainDTO dto) {
		
		int result = 0;
		
		Connection conn = DBconn.getConnection();
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			sql = "update customer set pw = ?, name = ?, tel = ?";
			sql += "where id = ?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, dto.getPw());
			pstmt.setString(2, dto.getName());
			pstmt.setString(3, dto.getTel());
			pstmt.setString(4, dto.getId());
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			
			} catch (Exception e) {
				System.out.println(e.toString());
		}
		
		return result;
	}
	
	
	//3. delete
	
	public int deleteDate(String id, String pw) {
		
		int result = 0;
		
		Connection conn = DBconn.getConnection();
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			sql = "delete customer where id = ? and pw = ?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return result;
	}
	
	//4. selectAll
	
	public List<trainDTO> getList(){
		
		List<trainDTO> lists = new ArrayList<trainDTO>();
		Connection conn = DBConn.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			sql = "select id, pw, name, birth, tel, add, account";
			sql += "from customer order by name";
			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				trainDTO dto = new trainDTO();
				
				dto.setId(rs.getString("id"));
				dto.setPw(rs.getString("pw"));
				dto.setName(rs.getString("name"));
				dto.setBirth(rs.getString("birth"));
				dto.setTel(rs.getString("tel"));
				dto.setAdd(rs.getString("add"));
				dto.setAccount(rs.getString("account"));
				
				lists.add(dto);
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return lists;
	}
	
	
	//5. searchId
	
	private Connection getConnection() {
		// TODO Auto-generated method stub
		return null;
	}


	public List<trainDTO> getList(String id){
		
		List<trainDTO> lists = new ArrayList<trainDTO>();
		Connection conn = DBconn.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;
		
		try {
			sql = "select id, pw, name, birth, tel, add, account";
			sql += "from customer where id = ?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				trainDTO dto = new trainDTO();
				
				dto.setId(rs.getString("id"));
				dto.setPw(rs.getString("pw"));
				dto.setName(rs.getString("name"));
				dto.setBirth(rs.getString("birth"));
				dto.setTel(rs.getString("tel"));
				dto.setAdd(rs.getString("add"));
				dto.setAccount(rs.getString("account"));
				
				lists.add(dto);
				
			}
			
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return lists;
	}
	
}
