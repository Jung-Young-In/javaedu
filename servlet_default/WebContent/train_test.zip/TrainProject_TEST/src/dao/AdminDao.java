package dao;

public class AdminDao {
	// 싱글톤 패턴
		private AdminDao() {}

		private static AdminDao instance;

		public static AdminDao getInstance() {
			if (instance == null) {
				instance = new AdminDao();
			}
			return instance;
		}
}
