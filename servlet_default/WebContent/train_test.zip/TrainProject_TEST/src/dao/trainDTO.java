package dao;

public class trainDTO {

	private String id;
	private String pw;
	private String name;
	private String birth;
	private String tel;
	private String add;
	private String account;
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getPw() {
		return pw;
	}
	
	public void setPw(String pw) {
		this.pw = pw;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getBirth() {
		return birth;
	}
	
	public void setBirth(String birth) {
		this.birth = birth;
	}
	
	public String getTel() {
		return tel;
	}
	
	public void setTel(String tel) {
		this.tel = tel;
	}
	
	public String getAdd() {
		return add;
	}
	
	public void setAdd(String add) {
		this.add = add;
	}
	
	public String getAccount() {
		return account;
	}
	
	public void setAccount(String account) {
		this.account = account;
	}
	
	@Override
	public String toString() {
		String str = String.format("아이디 : %s \n이름 : %s \n생일 : %s \n번호 : %s \n주소 : %s \n",
									id, name, birth, tel, add);
		
		return str;
	}
}
