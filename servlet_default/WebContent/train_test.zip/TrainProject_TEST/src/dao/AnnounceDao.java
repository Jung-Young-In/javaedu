package dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import util.JDBCUtil;

public class AnnounceDao {
	// 싱글톤 패턴
	private AnnounceDao() {}

	private static AnnounceDao instance;

	public static AnnounceDao getInstance() {
		if (instance == null) {
			instance = new AnnounceDao();
		}
		return instance;
	}
	
	private JDBCUtil jdbc = JDBCUtil.getInstance();
	// 여기까지 공통으로 쓸 코드고 DAO에서
	// 공지사항 말고 다른 기능 구현할때도 이 윗쪽 부분은 다 공통으로 쓸거에요 DAO에 접근하는거라고 보면되고 
	
	// 요 밑에부터가 영인브로가 구현해야될 메서드들
	//공지사항 목록 조회 메서드
	public List<Map<String, Object>> selectAnnounceList(){
		String sql= " select a.ann_id, b.andim_id, a.ann_subject, a.ann_content, a.ann_date"
				+ " from announce a"
				+ " left outer join admin b"
				+ " on a.ann_id = b.admin_id"
				+ " order by a.andim_id desc";
		
		return jdbc.selectList(sql);
	}
	
	
	
	// java 에서는 insert, delete, update가 성공했을때 반환이 int 로 와요 1이면 성공, 0이면 실패 
	// 그래서 리턴이 int에요
	public int insertAnnounce(List<Object> param){
		String sql = " insert into announce ("
				+ "ann_id, ann_nm, ann_subject, ann_content, ann_date, ad_id"
				+ ") values (?, ?, ?, ?, ?, ?, ?)";
		List<Object> params = new ArrayList<Object>();
		for (int i = 0; i < param.size(); i++) {
			params.add(param.get(i));
		}
		return jdbc.update(sql, params);
	}
	//02-22
	//delete
	public int deleteAnnounce(List<Object> param) {
		String sql = "delete from announce ("
				+ "ann_id, ann_nm, ann_subject, ann_content, ann_date, ad_id"
				+ ")";
		List<Object> params = new ArrayList<Object>();
		for (int i = 0; i < param.size(); i++) {
			params.add(param.get(i));
		}
		return jdbc.update(sql, params);
		}
	
	//update
	public int updateAnnounce(List<Object> param) {
		String sql = "update announce ("
				+ "set ann_id, ann_nm, ann_subject, ann_content, ann_date, ad_id"
				+ ") where (?, ?, ?, ?, ?, ?, ?, ?)";
		List<Object> params = new ArrayList<Object>();
		for (int i = 0; i < param.size(); i++) {
			params.add(param.get(i));
		}
		return jdbc.update(sql, params);
	}
}

