package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import util.JDBCUtil;

public class UserDao {
	// 싱글톤 패턴
	private UserDao() {}

	private static UserDao instance;

	public static UserDao getInstance() {
		if (instance == null) {
			instance = new UserDao();
		}
		return instance;
	}
	
	//jdbc 객체 전역변수로 생성
	private JDBCUtil jdbc = JDBCUtil.getInstance();
	
	
	//
	public int insertUser(Map<String, Object> param){
		String sql = "insert into tb_jdbc_user values(?,?,?,?,?,?)"; //쿼리 작성
		
		//물음표의 값 담기 (들어가야할 값 순서데로)
		List<Object> p  = new ArrayList<>();
		p.add(param.get("CS_ID"));
		p.add(param.get("CS_PW"));
		p.add(param.get("CS_NM"));
		p.add(param.get("CS_BIR"));
		p.add(param.get("CS_HP"));
		p.add(param.get("CS_CARD"));
		
		return jdbc.update(sql,p);
		
	}         


	public Map<String, Object> selectUser(String userId, String password) {
		String sql = "select * from user where cs_id = ? and cs_pw = ?"; //아이디와 비밀번호가 모두 일치하는 회원을 찾는다.
		List<Object> param = new ArrayList<>();
		param.add(userId);
		param.add(password);
		
		return jdbc.selectOne(sql, param);
	}
}
